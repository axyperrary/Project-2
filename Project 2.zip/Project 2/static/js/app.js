console.log("Hello")

$(function () {
    $('[data-toggle="popover"]').popover()
  })

$('.popover-dismiss').popover({
trigger: 'focus'
})

function myFunction() 
{
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
    console.log("Here");
}

function init() 
{
    var selector = d3.select("#selDataset");
    var selector2 = d3.select("#selDataset2");

    d3.json("/json", function(data)
    {
        // Add movies images
        img_urls = data[0]['img_urls']
        let i = 0;
        let oldSrc = '/static/images/marvel_background.png';
        $('img[src="' + oldSrc + '"]').attr('src', function()
        {
            $(this).attr('src', img_urls[i]);
            i++;
        });

        // Add select items
        movie_titles = data[0]['movie_titles'];
        movie_titles.forEach((title) => 
        {
            selector
            .append("option")
            .text(title)
            .property("value", title);
        });
        items = ["First", "Second"];
        items.forEach((item) => 
        {
            selector2
            .append("option")
            .text(item)
            .property("value", item);
        });

        // Add first charts
        const firstMovie = movie_titles[0];

        // buildCharts(firstMovie);

        // buildGraphs(items[0]);

        buildWordsGraph(firstMovie);
    });
}

function optionChanged(newMovie) 
{
    // buildCharts(newMovie);
    buildWordsGraph(newMovie);
    console.log(newMovie);
}

function buildCharts(select_movie)
{
    d3.json("/json", function(data)
    {
        var title_lengths = [];
        var titleNames = [];
        let movie_titles = data[0]['movie_titles']
        for (let i = 0; i < movie_titles.length; i++)
        {
            movie = movie_titles[i];
            title_lengths.push(movie.length);
            titleNames.push(movie);
            if (select_movie == movie_titles[i])
            {
                var movie_index = i;
            }
        }

        // Pie Chart
        var character_names = ["black_panther","black_widow","bucky","captain_america",
        "falcon","hawkeye","hulk","iron_man",
        "loki","nick_fury","rhodey","scarlet_witch",
        "spiderman","thor","ultron","vision"];
        var img = new Image();
        img.src = 'static/images/marvel_background_2.jpg';

        var ctx = document.getElementById('myChart2').getContext('2d');

        var fillPattern = ctx.createPattern(img, 'repeat');

        var myPieChart = new Chart(ctx, {
            type: 'pie',
            data: {
				datasets: [{
                    data: ["0","0","0",".1",
                    "0","0","0",".89",
                    "0","0","0","0",
                    ".1",".3",".2","0"],
                    backgroundColor: fillPattern,
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }],
                labels: character_names
			},
            options: 
            {
                responsive: true,
                title: 
                {
                    display: false,
                    text: 'Most Popular'
                },
                legend: 
                {
                    display: false
                }
			}
        });

        // Bar Chart
        var grd = ctx.createLinearGradient(0, 0, 1200, 0);
        grd.addColorStop(0, "red");
        grd.addColorStop(1, "white");
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: titleNames,
                datasets: [{
                    label: 'Movie Score',
                    data: ['79', '61', '69', '72', '66', '70', '62', '80', '70', '76', '66', '64', '75', 
                        '72', '67', '73', '74', '88', '68', '70', '75', '75'],
                    backgroundColor: grd,
                    borderColor: grd,
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    });
}

init();

// Word Popularity Chart
function buildWordsGraph(movieTitle)
{
    var movie_words = {"Iron Man": [[".", 1024], [",", 612], ["I", 396], ["you", 335],
                        ["a", 1024], ["b", 612], ["c", 396], ["d", 335],
                        ["e", 1024], ["f", 612], ["g", 396], ["h", 335],
                        ["i", 1024], ["j", 612], ["k", 396], ["l", 335]]};

    var col_num = 0;
    var j = 0;

    for (let i = 1; i < 20; i++)
    {
        var graph_id = 'myChart3_' + i;
        if (i % 5 != 0)
        {
            d3.select('#character_graph_c' + col_num).append('div').attr('id', graph_id);

            let word = movie_words["Iron Man"][j];

            wordGraph(graph_id, word, j);
            
            j = j + 1;
        }
        else
            col_num = col_num + 1;
    }
}
function wordGraph(tagId, word, j)
{
    var num = j + 1;
    var tag = '#' + tagId;

    d3.select(tag).html('');

    d3.select(tag).append('p').text(num + '. ' + word[0]);

    // $('#character_graph_c0').fadeIn("slow");
}

// Character Chart
function buildGraphs(item)
{
    var character_names = ["black_panther","black_widow","bucky","captain_america",
                        "falcon","hawkeye","hulk","iron_man",
                        "loki","nick_fury","rhodey","scarlet_witch",
                        "spiderman","thor","ultron","vision"];
    var col_num = 0;
    var j = 0;
    for (let i = 1; i < 20; i++)
    {
        var graph_id = 'myChart3_' + i;
        if (i % 5 != 0)
        {
            d3.select('#character_graph_c' + col_num).append('canvas').attr('id', graph_id);
            let name = character_names[j];
            if (item === "First")
            {
                constructGraphs(graph_id, name);       
            }
            else if (item === "Second")
            {
                // characterGraph();
                characterGraph(graph_id, name);
            }
            j = j + 1;
        }
        else
            col_num = col_num + 1;
    }
}

function optionChanged2(item) 
{
    buildWordsGraph(item, 0);
}

function characterGraph(id, name)
{
    var tag = '#' + id;
    d3.json('/characters', function(data)
    {
        let d = data[0];
        console.log(d);
        // for (let i = 0; i < d.length; i++)
        // {
        //     d3.select(tag).append().text('Yo');
        // }
        var img = new Image();
        img.src = 'static/images/marvel_background.png';
        var ctx = document.getElementById(id).getContext('2d');
        var grd = ctx.createLinearGradient(0, 0, 450, 0);
        grd.addColorStop(0, "red");
        grd.addColorStop(1, "white");
        var fillPattern = ctx.createPattern(img, 'repeat');
        var chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                datasets: [{
                    label: name,
                    backgroundColor: fillPattern,
                    borderColor: 'rgb(255, 99, 132)',
                    data: [50, 10, 5, 2, 20, 30, 45]
                }]
            },
            options: {}
        });
    });
}

function constructGraphs(id, name)
{
    var img = new Image();
    img.src = 'static/images/marvel_background.png';
    var values = [];
    var names = [];
    d3.json('/characters', function(data)
    {
        for (let i = 0; i < data.length; i++)
        {
            values.push(data[i][1]);
            names.push(data[i][0]);
        }
        var ctx = document.getElementById(id).getContext('2d');
        var fillPattern = ctx.createPattern(img, 'repeat');
        var chart = new Chart(ctx, {
            type: 'horizontalBar',
            data: {
                labels: names,
                datasets: [{
                    label: name,
                    backgroundColor: fillPattern,
                    borderColor: 'rgb(255, 255, 255)',
                    data: values
                }]
            },
            options: {}
        });
    });
}