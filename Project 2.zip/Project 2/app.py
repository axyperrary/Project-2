from flask import Flask, render_template
from flask_pymongo import PyMongo
from bs4 import BeautifulSoup
from splinter import Browser
import pandas as pd
import datetime as dt

import json
from bson.json_util import dumps

import operator

import nltk
# nltk.download('punkt')
from nltk.tokenize import sent_tokenize
from nltk.tokenize import word_tokenize
from nltk.probability import FreqDist

app = Flask(__name__)

app.config["MONGO_URI"] = "mongodb://localhost:27017/marvel_db"
mongo = PyMongo(app)

@app.route('/')
def index():
    collection = mongo.db.movies.find_one()
    return render_template("index.html", collection=collection["movie_titles"])

@app.route('/about')
def main():
    collection = mongo.db.movies.find_one()
    return render_template("about.html", collection=collection["movie_titles"])

@app.route('/scrape')
def scrapper():
    movies = mongo.db.movies
    movie_data = scrape_all()
    movies.update({}, movie_data, upsert=True)
    return (f"Scrapping Successful, <br>")

@app.route('/json')
def get_json():
    movies = mongo.db.movies.find()
    myDict = list(movies)
    return dumps(myDict)

@app.route('/names')
def get_names():
    movies = mongo.db.movies.find_one()
    myDict = movies["movie_titles"]
    return dumps(myDict)

@app.route('/characters')
def get_characters():
    # characters = mongo.db.characters
    # executable_path = {'executable_path': '/usr/Local/bin/chromedriver'}
    # browser = Browser('chrome', **executable_path)
    # titles = get_titles(browser)
    # scripts = get_scripts(browser, titles)
    # data = {
    #     "movie_scripts": scripts
    # }
    # characters.update({}, data, upsert=True)

    json_dump = mongo.db.characters.find_one()
    myDict = json_dump['movie_scripts']
    # print(myDict[0])

    # Script Analysis

    first_script = myDict[0]
    first_script = first_script.strip()

    # test = sent_tokenize(first_script)

    tokenized_word = word_tokenize(first_script)
    fdist = FreqDist(tokenized_word)

    # print(fdist.most_common(16))

    # return ("Successful.")
    return dumps(list(fdist.most_common(4)))

@app.route('/analyze-script')
def analyze_script():
    # http://www.screenplaysandscripts.com/script_files/A/AVENGERS,%20THE%20(2012)%20Joss%20Whedon%20(Shooting).pdf
    script_file = open('The Avengers (2012) original script.rtf', 'r')
    data = script_file.read()
    data = data.strip()
    # words = data.split(' ')
    tokenized_word = word_tokenize(data)
    print(tokenized_word)
    return ('Successful')

def scrape_all():
    executable_path = {'executable_path': '/usr/Local/bin/chromedriver'}
    browser = Browser('chrome', **executable_path)

    # Get movie titles
    titles = get_titles(browser)

    # Get scripts
    # scripts = get_scripts(browser, titles)

    # Get imgaes and scores
    images = get_images(browser, titles)

    # scripts = clean_scripts()

    timestamp = dt.datetime.now()

    data = {
        "movie_titles": titles,
        # "scripts": scripts,
        "img_urls": images,
        # "scores": scores,
        "last_modified": timestamp
    }

    browser.quit()
    return data

def get_titles(browser):
    url = 'https://en.wikipedia.org/wiki/List_of_Marvel_Cinematic_Universe_films'
    browser.visit(url)
    
    html = browser.html
    soup = BeautifulSoup(html, 'html.parser')

    titles = []

    try:
        for data in soup.find_all('span', class_="toctext", limit=26):
            titles.append(data.get_text())
    except AttributeError:
        return None

    titles = fix_titles(titles)
    return titles

def get_scripts(browser, titles):
    movie_scripts = []

    for title in titles:
        url = 'https://www.springfieldspringfield.co.uk/movie_script.php?movie='
        url = url + title
        browser.visit(url)
        html = browser.html
        soup = BeautifulSoup(html, 'html.parser')

        try:
            movie_script = soup.find('div', class_="scrolling-script-container").get_text()
            movie_scripts.append(movie_script)
        except AttributeError:
            movie_scripts.append("None")

    return movie_scripts

def get_images(browser, titles):
    img_urls = []
    movie_scores = []

    for title in titles:
        url = 'https://www.imdb.com/'
        browser.visit(url)

        browser.find_by_css('#navbar-query').fill(title)
        browser.find_by_id('navbar-submit-button').first.click()

        # browser.find_by_tag('td').click()
        # browser.click_link_by_text('Iron Man')

        html = browser.html
        soup = BeautifulSoup(html, 'html.parser')

        img = soup.select_one('.primary_photo')
        img_url = img.a.img.get('src')
        img_urls.append(img_url)

        # title_click_name = soup.select_one('.result_text')
        # title_click_name = title_click_name.a.get_text()

        # browser.click_link_by_text(title_click_name)

        # html = browser.html
        # soup = BeautifulSoup(html, 'html.parser')

        # try:
        #     score = soup.select_one('.metacriticScore')
        #     score = score.span.get_text()
        #     movie_scores.append(score)
        # except AttributeError:
        #     movie_scores.append('None')
        # print(movie_scores)

    return img_urls

def fix_titles(titles):
    for i in range(len(titles)):
        titles[i] = titles[i][:-7]
        titles[i] = titles[i].replace(" ", "-")
        titles[i] = titles[i].replace(":", "") 
        titles[i] = titles[i].replace(".", "")
    del(titles[0])
    del(titles[0])
    titles.remove("Ph")
    titles.remove("Phas")

    return titles

def clean_scripts():
    movie_scripts = []
    movies = mongo.db.movies.find_one()
    # print(len(movies['scripts']))
    for i in range(len(movies['scripts'])):
        script = movies['scripts'][i]
        words = script.split(' ')
        counts = dict()
        for word in words:
            word = word.replace('.', '')
            word = word.replace(',', '')
            word = word.replace('!', '')
            word = word.replace("'s", '')
            # word = word.replace('...', '')
            word = word.replace('?', '')
            if (word in counts):
                counts[word] += 1
            else:
                counts[word] = 1
        sorted_x = sorted(counts.items(), key=operator.itemgetter(1))
        movie_scripts.append(sorted_x)
    # print(movie_scripts[0][0])
    return movie_scripts

# clean_scripts()

if __name__ == "__main__":
    app.run()